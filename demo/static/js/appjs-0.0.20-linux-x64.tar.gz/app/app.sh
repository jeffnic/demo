#!/bin/sh

./data/bin/node --harmony ./data/app.js 
